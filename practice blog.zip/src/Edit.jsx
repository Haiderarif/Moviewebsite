import React from 'react'
import Same from './Same'

function Edit() {
  return (
    <div className='Edit'>
   <Same title='Edit' btn='Update'/>
    </div>
  )
}

export default Edit