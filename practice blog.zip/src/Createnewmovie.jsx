import React from 'react'
import Same from './Same'
import { Link } from 'react-router-dom/cjs/react-router-dom.min'

function Createnewmovie() {
  return (
    <div className='createmoviepage'>
      
      <Same title='Create a new movie' btn="Submit"/>
 
  
    </div>
  )
}

export default Createnewmovie