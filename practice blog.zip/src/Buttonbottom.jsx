import React from 'react'

function Buttonbottom() {
  return (
    <div className='buttonbottom'>
     <a className='noborderbutton' href="#">Prev</a>  
     <a className='pagebutton1' href="#">1</a>  
     <a className='pagebutton2' href="#">2</a>  
        <a className='noborderbutton2' href="#">Next</a>  
    </div>
  )
}

export default Buttonbottom